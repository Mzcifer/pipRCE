msg = r"""
                              _ 
                             | |
 _ ____      ___ __   ___  __| |
| '_ \ \ /\ / / '_ \ / _ \/ _` |
| |_) \ V  V /| | | |  __/ (_| |
| .__/ \_/\_/ |_| |_|\___|\__,_|
| |                             
|_|             

"""

#Linux
#f = open("/dev/tty", "w")
#print(msg, file=f)
#print(open("/etc/passwd").read(), file=f)

#Windows
import os
os.system("calc.exe")
